<?php 

// pengkondisian / percabangan
// if else
// if else if else
// ternary
// switch

$x = 20;
if ( $x < 20) {

	echo "benar";
} elseif ($x == 20) {
	echo "bingo!";
}

else {
	echo "salah";
}



 ?>